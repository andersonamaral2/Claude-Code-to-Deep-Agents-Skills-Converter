# Modelo do relatório executivo (uma página)

Gere o relatório em Markdown, exatamente nesta estrutura e ordem. Título curto, sem enfeite. Linguagem executiva: frases com consequência, sem adjetivo vazio. Sempre "%" e "/ano", nunca "por cento" ou "por ano". Nunca use travessão.

---

## Diagnóstico de Automação: [nome do processo]

**Data:** [data] · **Método:** Automação com Critério, de Patricia Costa (Scoras Academy)

### Veredito: [Automatizar | Adiar com condições | Simplificar antes | Desligar o processo | Observar antes de decidir]

[O porquê em até 3 frases, citando os fatos da entrevista que sustentam o veredito. Sem hedge desnecessário: o veredito é uma recomendação de verdade.]

### O processo em números

| | |
|---|---|
| Frequência | [X execuções/semana ou /mês] |
| Duração por execução | [tempo] |
| Trocas de mão | [n] |
| Retrabalho | [proporção real relatada, ex.: 3 de cada 10] |
| Custo atual estimado | [R$ faixa/ano, declarada como ordem de grandeza] |

### Degrau de tecnologia recomendado

[Regra fixa | IA | Agente | Não se aplica]: [justificativa em 1 a 2 frases ancorada na entrevista. Se a pessoa chegou querendo degrau acima, registrar a diferença.]

### Tarefas antes de qualquer contrato

[Uma linha por "não" das sete perguntas, no formato: **Tarefa** · responsável sugerido · critério de conclusão. Se todas as respostas foram sim, escrever: "Nenhuma pendência estrutural identificada nas sete perguntas. Siga para a conta completa com o fornecedor."]

### A conta completa

Impacto estimado: [R$ faixa/ano]. Conta completa da automação: [R$ faixa/ano], incluindo [citar as 2 ou 3 linhas invisíveis mais relevantes para este caso]. Regra aplicada: o impacto/ano precisa ser confortavelmente maior que a conta completa/ano. Neste caso: [fecha | não fecha | fecha com margem apertada].

### Lacunas de mapeamento

[Somente se houver: o que ninguém soube responder e como levantar (ex.: "ninguém soube dizer a proporção de retrabalho; observar 10 execuções antes de orçar"). Se não houver, omitir a seção inteira.]

---

*Diagnóstico individual pelo método do curso De Gargalos a Agentes. A pontuação das 7 variáveis, a priorização entre processos e a Calculadora de ROI fazem parte da Ferramenta de Diagnóstico, exclusiva do curso: gargalos.scorasacademy.com.br*

---

Regras de geração:

- O relatório inteiro precisa caber em uma página: seja denso, não completo. O que não couber, não entra.
- Números sempre com a origem na conversa; nada inventado. Faixa declarada como faixa.
- A linha final em itálico é a única menção promocional permitida no relatório. Não adicionar outras.
- Se o veredito for "Desligar o processo" ou "Simplificar antes", omitir as seções "Degrau de tecnologia" e "A conta completa" (não fazem sentido para processo que não deve ser automatizado agora) e incluir no lugar uma seção "### Próximo passo" com a ação concreta de desligamento ou simplificação.
